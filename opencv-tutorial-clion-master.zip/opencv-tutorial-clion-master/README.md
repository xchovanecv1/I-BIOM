# opencv-tutorial-clion
This project is an OpenCV example, just show how to configure CMakeLists.txt.
The result of the project :
![alt tag](https://raw.githubusercontent.com/ZHAJOR/opencv-tutorial-clion/master/img/example.png)

# How to
Just git clone the project and open it with clion, then run it.

# Blog Article

I wrote a blog article to install OpenCV on osx or ubuntu, feel free to take a look [here](https://blog.zhajor.com/2016/10/install-opencv-and-make-a-test-project-with-clion/).